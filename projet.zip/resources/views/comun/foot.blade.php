<footer class="sticky-footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright © FEG 2020</small>
        </div>
    </div>
</footer>
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
</a>
</div>