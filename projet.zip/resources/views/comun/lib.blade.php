
<!-- Core plugin JavaScript-->
<script src="{{asset('assets\library\jquery-easing\jquery.easing.min.js')}}"></script>
<!-- Custom scripts for all pages-->
<script src="{{asset('assets\library\sb-admin\js\sb-admin.min.js')}}"></script>

<script src="{{asset('assets\library\rancho\js\function.js')}}" rel="stylesheet"></script>
