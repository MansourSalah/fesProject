<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta name="csrf-token" content="{{ csrf_token() }}" />

<title>SOL’R SHEMSY |Made in morocco</title>
<!-- Favicons -->
<link href="{{asset('assets\img\logo.png')}}" rel="icon">
<link href="{{asset('assets/library/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
<!-- Custom fonts for this template-->
<link href="{{asset('assets/library/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css">
<!-- Custom styles for this template-->
<link href="{{asset('assets/library/sb-admin/css/sb-admin.css')}}" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="{{asset('assets\library\rancho\css\style.css')}}" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.js"></script>

<script src="{{asset('assets\library\jquery\jquery.min.js')}}"></script>
<script src="{{asset('assets\library\bootstrap\js\bootstrap.bundle.min.js')}}"></script>


