<div class="modal" id="verifier-m">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
            <h4 class="modal-title">Initialiser</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <h6>Est ce que vous voulez initialiser les paramètres de votre système ?</h6>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-success" onclick="clear_mem()">Oui</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Non</button>
        </div>
    </div>
  </div>
</div>

